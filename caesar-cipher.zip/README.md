# pythonminiprojects
Here are some fun python mini project codes made on replit
